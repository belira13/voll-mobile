import axios from "axios";

const api = axios.create({
    baseURL: "http://10.91.140.97:3000"
});

export default api;